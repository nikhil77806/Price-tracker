import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

def alert_system(product_title, product_url):
    sender_email = "b.nikithagoud@gmail.com"
    receiver_email = "b.nikithagoud@gmail.com"
    password = "zvvd exdr gvwf slno"

    subject = f"Price Alert for: {product_title}"
    body = f"The price has dropped! Check it here:\n{product_url}"

    msg = MIMEMultipart()
    msg["From"] = sender_email
    msg["To"] = receiver_email
    msg["Subject"] = subject
    msg.attach(MIMEText(body, "plain"))

    try:
        with smtplib.SMTP("smtp.gmail.com", 587) as server:
            server.starttls()
            server.login(sender_email, password)
            server.send_message(msg)
            print("Email sent.")
    except Exception as e:
        print("Failed to send email:", e)